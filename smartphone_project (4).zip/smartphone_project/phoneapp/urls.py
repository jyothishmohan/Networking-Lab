from django.urls import path
from . import views

urlpatterns = [
    path('', views.welcome_page, name='welcome'),
    path('predict/', views.predict_addiction, name='predict_addiction'),
    path('suggestions/', views.show_suggestions, name='show_suggestions'),
]
