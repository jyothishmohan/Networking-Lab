import joblib
import pandas as pd
from django.shortcuts import render, redirect

# --------------------------
# Load model, scaler, and feature columns once
# --------------------------
model = joblib.load("svr_model.pkl")
scaler = joblib.load("scaler.pkl")
feature_columns = joblib.load("feature_columns.pkl")

# Maximum possible score of Addiction_Level in your dataset
MAX_SCORE = 10.0


# --------------------------
# Helper Functions
# --------------------------
def addiction_category(score_percentage):
    """
    Convert a 0-100% score into a category.
    """
    if score_percentage <= 40:
        return "Low"
    elif score_percentage <= 70:
        return "Moderate"
    else:
        return "High"


def suggestions_for_category(category):
    """
    Provide exactly 8 typed suggestions based on addiction category.
    """
    if category == "Low":
        return [
            "Maintain balanced phone use.",
            "Continue good sleeping and study habits.",
            "Take short breaks from the phone during study hours.",
            "Avoid phone distractions during meals.",
            "Keep notifications minimal.",
            "Encourage offline hobbies.",
            "Track daily usage.",
            "Stay mindful of phone habits."
        ]
    elif category == "Moderate":
        return [
            "Reduce non-educational screen time.",
            "Engage more in outdoor activities.",
            "Set daily app usage limits.",
            "Schedule phone-free periods.",
            "Prioritize sleep over late-night usage.",
            "Use productivity apps to limit distractions.",
            "Talk to friends/family offline.",
            "Track your screen time weekly."
        ]
    else:  # High
        return [
            "Seek guidance from parents or teachers.",
            "Avoid phone use before bed.",
            "Follow a planned digital detox routine.",
            "Set strict daily usage limits.",
            "Keep phone out of reach during work/study.",
            "Replace social media time with hobbies.",
            "Join support groups for digital wellness.",
            "Track and reflect on usage daily."
        ]


# --------------------------
# Views
# --------------------------
def welcome_page(request):
    """
    Home page with welcome message and link to prediction form.
    """
    return render(request, "welcome.html")


def predict_addiction(request):
    """
    Process form data, predict smartphone addiction percentage, 
    determine category, and render result page with background image.
    """
    if request.method == "POST":
        # Collect input values from form
        values = [
            float(request.POST['Age']),
            int(request.POST['Gender']),
            float(request.POST['Daily_Usage_Hours']),
            float(request.POST['Sleep_Hours']),
            float(request.POST['Academic_Performance']),
            float(request.POST['Exercise_Hours']),
            int(request.POST['Parental_Control']),
            float(request.POST['Screen_Time_Before_Bed']),
            float(request.POST['Phone_Checks_Per_Day']),
            float(request.POST['Apps_Used_Daily']),
            float(request.POST['Time_on_Social_Media']),
            float(request.POST['Time_on_Gaming']),
            float(request.POST['Time_on_Education']),
        ]

        # Prepare DataFrame for model
        df = pd.DataFrame([values], columns=feature_columns)

        # Scale input and predict
        scaled_input = scaler.transform(df)
        score_raw = float(model.predict(scaled_input)[0])

        # Clamp raw score to expected range
        score_raw = max(0.0, min(score_raw, MAX_SCORE))

        # Convert to percentage
        score_percentage = (score_raw / MAX_SCORE) * 100.0

        # Determine category
        category = addiction_category(score_percentage)

        # Determine background image based on category
        if category == "Low":
            bg_image = "images/low.jpg"
        elif category == "Moderate":
            bg_image = "images/moderate.jpg"
        else:  # High
            bg_image = "images/high.jpg"

        # Save to session for suggestions page
        request.session['category'] = category
        request.session['score_percentage'] = round(score_percentage, 2)

        # Prepare message
        message = f"You have a {score_percentage:.2f}% risk of smartphone addiction, if you continue using this way!!"

        # Render result page
        return render(request, "addiction_result.html", {
            "score": round(score_percentage, 2),
            "raw_score": round(score_raw, 2),
            "category": category,
            "message": message,
            "bg_image": bg_image
        })

    # GET request: show form
    return render(request, "form.html")


def show_suggestions(request):
    """
    Display 8 typed suggestions based on addiction category.
    """
    # Retrieve category and percentage from session
    category = request.session.get('category', 'Moderate')
    score_percentage = request.session.get('score_percentage', 0)

    # Get 8 typed suggestions
    suggestions = suggestions_for_category(category)

    context = {
        "category": category,
        "percentage": score_percentage,
        "suggestions": suggestions
    }
    return render(request, "suggestions.html", context)
